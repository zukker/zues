package lsdsoft.zeus.methods;


import javax.swing.table.*;
import lsdsoft.metrolog.*;
import java.text.*;


/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2004</p>
 * <p>Company: Ural-Geo</p>
 * @author lsdsoft
 * @version 0.9
 */

public class MeasureTableModel
    extends AbstractTableModel {
    private static final int COLUMN_COUNT = 6;
    private String[] columnNames = {
        "<html><center><font size=-2><b>�����.<br>��������</b></font>",
        "<html><center><font size=-2><b>���������<br>��������",
        "<html><center><font size=-2><b>��������<br>�� �������",
        "<html><center><font size=-2><b>������ ���.<br>�����������</b></font></center>",
        "<html><center><font size=-2><b>���</b></font></center>",
        "<html><center><font size=-2><b>�������<br>��������</b></font></center>",
    };
    private String VALID = "<html><center><font size=-1 color=#00cc00><b>�����";
    private String INVALID = "<html><font size=-1 color=#ff0000><b>�� �����";

    protected MeasureTable table;
    public MeasureTableModel( MeasureTable table ) {
        super();
        this.table = table;
    }

    public int getRowCount() {
        return table.size();
    }

    public int getColumnCount() {
        return COLUMN_COUNT;
    }

    public Object getValueAt( int rowIndex, int columnIndex ) {
        MeasureChain chain = table.getChain( rowIndex );
        Object obj;
        double value = 0;
        NumberFormat form = NumberFormat.getInstance();
        form.setMaximumFractionDigits( 3 );
        String str = "";
        switch ( columnIndex ) {
            case 0:
                str = form.format( chain.getReproductionValue() );
                break;
            case 1:
                str = form.format( chain.getAccurateAverage() );
                break;
            case 2:
                str = form.format( chain.getToolAverage() );
                break;
            case 3:
                str = form.format( chain.getDelta() );
                break;
            case 4:
                str = form.format( chain.getSKO() );
                break;
            case 5:
                str = chain.isValid() ? VALID : INVALID;

        }
        return str;
    }

    public String getColumnName( int col ) {
        return columnNames[col];
    }

    public Class getColumnClass( int c ) {
        return columnNames[c].getClass();
    }

}