package lsdsoft.zeus.methods;

import lsdsoft.zeus.*;

/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2004</p>
 * <p>Company: Ural-Geo</p>
 * @author lsdsoft
 * @version 1.0
 */

public class ION1GradBaseViewer
extends AbstractMethodsViewer {
    public ION1GradBaseViewer() {
    }
}