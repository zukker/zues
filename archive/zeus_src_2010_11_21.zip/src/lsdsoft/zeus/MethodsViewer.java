package lsdsoft.zeus;

import java.util.*;

/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2004</p>
 * <p>Company: Ural-Geo</p>
 * @author lsdsoft
 * @version 0.9
 */

public interface MethodsViewer {
    public void setProperties(Properties props);
    public void setWorkState(WorkState workState);
    public void start();
}