package lsdsoft.metrolog.im;

public interface IMDataEventListener {
  public void dataEvent(IMDataEvent ev);
};
