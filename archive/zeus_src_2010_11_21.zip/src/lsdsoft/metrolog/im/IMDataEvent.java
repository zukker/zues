package lsdsoft.metrolog.im;

import lsdsoft.units.*;

public class IMDataEvent {
  private In�linometerAngles angles;

  public IMDataEvent(In�linometerAngles angles) {
    this.angles = angles;
  }
  public Angle getRotate() {
    return angles.rotate;
  }
  public Angle getZenit() {
    return angles.zenith;
  }
  public Angle getAzimut() {
    return angles.azimuth;
  }
};

