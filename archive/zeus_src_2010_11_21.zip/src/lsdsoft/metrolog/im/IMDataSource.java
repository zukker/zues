package lsdsoft.metrolog.im;

import lsdsoft.units.*;
import lsdsoft.metrolog.*;
import java.util.*;

public class IMDataSource extends WellToolDataSource {
  private final static String SOURCE_ID = "ds.wt.imempty";
  protected ArrayList dataEventListeners;
  protected In�linometerAngles angles;
  public IMDataSource() {
    tool = null;
    UID = SOURCE_ID;
  }
  //public String getUID() {
  //  return id;
 // }
  void addDataEventListener(IMDataEventListener evListener) {
    if(!dataEventListeners.contains(evListener))
        dataEventListeners.add(evListener);
  }
  void removeDataEventListener(IMDataEventListener evListener) {
    dataEventListeners.remove(evListener);
  }
  void getLastAngles(In�linometerAngles ang) {
    ang = angles;
  }

  public void getAngles(In�linometerAngles ang) {
    ang = angles;
  }
};

