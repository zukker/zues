package lsdsoft.util;

/**
 * <p>Title: grade characteristic</p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: CMI Ural-Geo</p>
 * @author lsdsoft
 * @version 1.0
 */

public interface GradChar {
  double Calc(double Value);
}