package lsdsoft.zeus;

/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2004</p>
 * <p>Company: Ural-Geo</p>
 * @author lsdsoft
 * @version 1.0
 */

public class AliasException extends Exception {
    public AliasException() {
        super("Alias not created");
    }

}