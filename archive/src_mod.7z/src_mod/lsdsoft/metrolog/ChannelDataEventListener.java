package lsdsoft.metrolog;

public interface ChannelDataEventListener {
  public void channelEvent(ChannelDataEvent ev);
};

