package lsdsoft.metrolog.unit;


/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2004</p>
 * <p>Company: Ural-Geo</p>
 * @author lsdsoft
 * @version 0.9
 */

public class CheckUnitException
    extends Exception {
    public CheckUnitException() {
    }

    public CheckUnitException( String message ) {
        super( message );
    }

}